# 🛡️ NasTech Guardian v3.0

Multi-agent CI/CD orchestration for Android + Termux.

## Quick Install (Termux on Android)

```bash
# Option A — from GitHub (recommended)
pkg install git -y
git clone https://github.com/nastech-ai/NasGuardian ~/nastech-guardian
cd ~/nastech-guardian
bash termux_install.sh

# Option B — from this ZIP bundle
unzip nastech-guardian-v3.0.zip -d ~/nastech-guardian
cd ~/nastech-guardian
bash termux_install.sh
```

## What gets installed

- Python 3 + all bot dependencies
- Telegram bot running in tmux (always-live)
- Auto-start via Termux:Boot on device reboot
- `nastech-start` / `nastech-stop` / `nastech-status` / `nastech-logs` aliases

## Telegram Bot Commands

| Category | Commands |
|---|---|
| 🔑 API Keys | `/apikeys` `/setkey KEY value` `/testkeys` |
| 🤖 AI Chat | `/ask` `/explain` `/review` `/run` `/fix_error` |
| 🔍 Repos | `/addrepo` `/repos` `/dashboard` `/audit` `/scanall` |
| ⚙️ Pipeline | `/status` `/scan` `/build` `/repair` `/release` `/health` |
| 🛠️ Tools | `/ocr` `/summarize` `/translate` `/daily` |

## Change API Keys via Telegram

```
/apikeys              — show all keys (masked)
/setkey GROQ_API_KEY gsk_xxx       — update Groq key
/setkey GEMINI_API_KEY AIzaxx      — update Gemini key
/setkey OPENROUTER_API_KEY sk-xx   — update OpenRouter key
/setkey GITHUB_TOKEN ghp_xxx       — update GitHub PAT
/testkeys             — test all API connections
```

## Required Secrets

```
TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID
GROQ_API_KEY
GEMINI_API_KEY
OPENROUTER_API_KEY
GITHUB_TOKEN   (ghp_... personal access token)
```

## Links

- 🤖 Bot: @Nightscafebot
- 📱 NasTerminal: https://github.com/nastech-ai/NasTerminal
- 🛡️ NasGuardian: https://github.com/nastech-ai/NasGuardian
