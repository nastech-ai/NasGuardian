#!/usr/bin/env bash
# NasTech Config — API Key Manager
# Usage: bash nastech_config.sh [set KEY value | show | test]

ENV_FILE="$HOME/.nastech_env"

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'; N='\033[0m'; BOLD='\033[1m'

mask_val() {
    local v="$1"
    [[ -z "$v" ]] && echo "❌ not set" && return
    echo "✅ ${v:0:6}…${v: -3}"
}

load_env() {
    [[ -f "$ENV_FILE" ]] && source "$ENV_FILE" 2>/dev/null || true
}

save_key() {
    local key="$1" val="$2"
    touch "$ENV_FILE"
    if grep -q "^export ${key}=" "$ENV_FILE" 2>/dev/null; then
        sed -i "s|^export ${key}=.*|export ${key}=\"${val}\"|" "$ENV_FILE"
    else
        echo "export ${key}=\"${val}\"" >> "$ENV_FILE"
    fi
    export "${key}=${val}"
    echo -e "${G}✓${N} ${key} updated"
}

cmd_show() {
    load_env
    echo ""
    echo -e "${BOLD}🔑 NasTech API Keys${N}"
    echo "───────────────────────────────────"
    echo -e "  GROQ_API_KEY:       $(mask_val "${GROQ_API_KEY:-}")"
    echo -e "  GEMINI_API_KEY:     $(mask_val "${GEMINI_API_KEY:-}")"
    echo -e "  OPENROUTER_API_KEY: $(mask_val "${OPENROUTER_API_KEY:-}")"
    echo -e "  TELEGRAM_BOT_TOKEN: $(mask_val "${TELEGRAM_BOT_TOKEN:-}")"
    echo -e "  TELEGRAM_CHAT_ID:   $(mask_val "${TELEGRAM_CHAT_ID:-}")"
    echo -e "  GITHUB_TOKEN:       $(mask_val "${GITHUB_TOKEN:-}")"
    echo ""
    echo -e "  Config file: ${ENV_FILE}"
    echo ""
}

cmd_set() {
    local key="$1" val="$2"
    [[ -z "$key" || -z "$val" ]] && {
        echo -e "${R}Usage: bash nastech_config.sh set KEY value${N}"; exit 1; }
    save_key "$key" "$val"
    echo -e "  Run: ${Y}source ${ENV_FILE}${N} to apply in current shell"
}

cmd_test() {
    load_env
    echo ""
    echo -e "${BOLD}🔍 Testing API Keys…${N}"

    # Groq
    if [[ -n "${GROQ_API_KEY:-}" ]]; then
        resp=$(curl -s -o /dev/null -w "%{http_code}" \
            -H "Authorization: Bearer ${GROQ_API_KEY}" \
            https://api.groq.com/openai/v1/models 2>/dev/null)
        [[ "$resp" == "200" ]] \
            && echo -e "  ${G}✅ Groq — OK${N}" \
            || echo -e "  ${R}❌ Groq — HTTP ${resp}${N}"
    else
        echo -e "  ${R}❌ Groq — not set${N}"
    fi

    # Gemini
    if [[ -n "${GEMINI_API_KEY:-}" ]]; then
        resp=$(curl -s -o /dev/null -w "%{http_code}" \
            "https://generativelanguage.googleapis.com/v1beta/models?key=${GEMINI_API_KEY}" 2>/dev/null)
        [[ "$resp" == "200" ]] \
            && echo -e "  ${G}✅ Gemini — OK${N}" \
            || echo -e "  ${R}❌ Gemini — HTTP ${resp}${N}"
    else
        echo -e "  ${R}❌ Gemini — not set${N}"
    fi

    # OpenRouter
    if [[ -n "${OPENROUTER_API_KEY:-}" ]]; then
        resp=$(curl -s -o /dev/null -w "%{http_code}" \
            -H "Authorization: Bearer ${OPENROUTER_API_KEY}" \
            https://openrouter.ai/api/v1/models 2>/dev/null)
        [[ "$resp" == "200" ]] \
            && echo -e "  ${G}✅ OpenRouter — OK${N}" \
            || echo -e "  ${R}❌ OpenRouter — HTTP ${resp}${N}"
    else
        echo -e "  ${R}❌ OpenRouter — not set${N}"
    fi

    # Telegram
    if [[ -n "${TELEGRAM_BOT_TOKEN:-}" ]]; then
        resp=$(curl -s "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe" 2>/dev/null \
            | python3 -c "import sys,json; d=json.load(sys.stdin); print('OK' if d.get('ok') else 'FAIL')" 2>/dev/null)
        [[ "$resp" == "OK" ]] \
            && echo -e "  ${G}✅ Telegram — OK${N}" \
            || echo -e "  ${R}❌ Telegram — FAIL${N}"
    else
        echo -e "  ${R}❌ Telegram Bot Token — not set${N}"
    fi
    echo ""
}

cmd_interactive() {
    load_env
    echo ""
    echo -e "${BOLD}${C}╔══════════════════════════════════════════════╗${N}"
    echo -e "${BOLD}${C}║  NasTech Config — API Key Manager             ║${N}"
    echo -e "${BOLD}${C}╚══════════════════════════════════════════════╝${N}"
    echo ""
    echo "  1) Show all keys"
    echo "  2) Set GROQ_API_KEY"
    echo "  3) Set GEMINI_API_KEY"
    echo "  4) Set OPENROUTER_API_KEY"
    echo "  5) Set TELEGRAM_BOT_TOKEN"
    echo "  6) Set TELEGRAM_CHAT_ID"
    echo "  7) Set GITHUB_TOKEN"
    echo "  8) Test all keys"
    echo "  q) Quit"
    echo ""
    read -rp "  Choice: " choice
    case "$choice" in
        1) cmd_show ;;
        2) read -rp "  GROQ_API_KEY: " v; save_key GROQ_API_KEY "$v" ;;
        3) read -rp "  GEMINI_API_KEY: " v; save_key GEMINI_API_KEY "$v" ;;
        4) read -rp "  OPENROUTER_API_KEY: " v; save_key OPENROUTER_API_KEY "$v" ;;
        5) read -rp "  TELEGRAM_BOT_TOKEN: " v; save_key TELEGRAM_BOT_TOKEN "$v" ;;
        6) read -rp "  TELEGRAM_CHAT_ID: " v; save_key TELEGRAM_CHAT_ID "$v" ;;
        7) read -rp "  GITHUB_TOKEN: " v; save_key GITHUB_TOKEN "$v" ;;
        8) cmd_test ;;
        q|Q) echo "Bye!"; exit 0 ;;
        *) echo -e "${Y}Unknown choice${N}" ;;
    esac
}

# Main
case "${1:-}" in
    show|list)      cmd_show ;;
    set)            cmd_set "${2:-}" "${3:-}" ;;
    test|check)     cmd_test ;;
    *)              cmd_interactive ;;
esac
