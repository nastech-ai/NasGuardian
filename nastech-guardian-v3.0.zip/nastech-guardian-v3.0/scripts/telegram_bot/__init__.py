"""NasTech Guardian Telegram Bot"""
